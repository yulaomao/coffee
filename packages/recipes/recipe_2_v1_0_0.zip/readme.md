Recipe Latte v1.0.0
