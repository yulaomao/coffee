Recipe TestCappuccino v2.0.0
